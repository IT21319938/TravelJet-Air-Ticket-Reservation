function m1(){
    document.getElementById('i1').style.display = "block";
    document.getElementById('i2').style.display = "block";
    document.getElementById('i3').style.display = "block";
    document.getElementById('i4').style.display = "block";
    document.getElementById('i5').style.display = "block";
    document.getElementById('i6').style.display = "block";
    document.getElementById('i7').style.display = "block";
    document.getElementById('i8').style.display = "block";
    document.getElementById('i9').style.display = "block";
    document.getElementById('i10').style.display = "block";
}

function m2(){
    document.getElementById('i1').style.display = "none";
    document.getElementById('i2').style.display = "block";
    document.getElementById('i3').style.display = "none";
    document.getElementById('i4').style.display = "none";
    document.getElementById('i5').style.display = "none";
    document.getElementById('i6').style.display = "none";
    document.getElementById('i7').style.display = "none";
    document.getElementById('i8').style.display = "none";
    document.getElementById('i9').style.display = "none";
    document.getElementById('i10').style.display = "none";
}

function m3(){
    document.getElementById('i1').style.display = "none";
    document.getElementById('i2').style.display = "none";
    document.getElementById('i3').style.display = "none";
    document.getElementById('i4').style.display = "none";
    document.getElementById('i5').style.display = "block";
    document.getElementById('i6').style.display = "none";
    document.getElementById('i7').style.display = "none";
    document.getElementById('i8').style.display = "none";
    document.getElementById('i9').style.display = "block";
    document.getElementById('i10').style.display = "block";
}

function m4(){
    document.getElementById('i1').style.display = "none";
    document.getElementById('i2').style.display = "none";
    document.getElementById('i3').style.display = "none";
    document.getElementById('i4').style.display = "none";
    document.getElementById('i5').style.display = "none";
    document.getElementById('i6').style.display = "none";
    document.getElementById('i7').style.display = "block";
    document.getElementById('i8').style.display = "none";
    document.getElementById('i9').style.display = "none";
    document.getElementById('i10').style.display = "none";
}

function m5(){
    document.getElementById('i1').style.display = "block";
    document.getElementById('i2').style.display = "none";
    document.getElementById('i3').style.display = "none";
    document.getElementById('i4').style.display = "none";
    document.getElementById('i5').style.display = "none";
    document.getElementById('i6').style.display = "block";
    document.getElementById('i7').style.display = "none";
    document.getElementById('i8').style.display = "none";
    document.getElementById('i9').style.display = "none";
    document.getElementById('i10').style.display = "none";
}